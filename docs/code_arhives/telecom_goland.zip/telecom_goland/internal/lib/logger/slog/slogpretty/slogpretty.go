package slogpretty

import (
	"log/slog"
	"os"
)

// Logging uses slog as in the source project; secrets are never logged.
func SetupPrettyLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(os.Stdout, &slog.HandlerOptions{Level: slog.LevelInfo}))
}
